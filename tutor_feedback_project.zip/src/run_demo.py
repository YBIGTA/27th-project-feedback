import os, pandas as pd
from tqdm import tqdm
from demo_data import data
from generator import generate_three_sections
from trend_pipeline import build_graph

OUT_PATH = "data/with_comments_demo.csv"

def main():
    rows = []
    for rec in tqdm(data, desc="Generating comments"):
        rows.append({**rec, **generate_three_sections(rec)})

    graph = build_graph()
    out = graph.invoke({"student_data": data})
    trend_text = out.get("numeric_trend_text", "")

    os.makedirs("data", exist_ok=True)
    df = pd.DataFrame(rows)
    if trend_text:
        df["_trend_summary_"] = trend_text
    df.to_csv(OUT_PATH, index=False, encoding="utf-8-sig")
    print(f"Saved -> {OUT_PATH}")
    if trend_text:
        print("\n[Trend Summary]\n", trend_text)

if __name__ == "__main__":
    main()
