import os
from statistics import mean
from typing import Dict, Any, List
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END

load_dotenv()
USE_LLM = bool(os.getenv("UPSTAGE_API_KEY"))

if USE_LLM:
    from langchain_upstage import ChatUpstage
    def get_llm(model="solar-pro-250422", temperature=0.2):
        return ChatUpstage(model=model, temperature=temperature, api_key=os.getenv("UPSTAGE_API_KEY"))

def _i(v, default=3):
    try: return int(v)
    except: return default

METRICS = {
    "attitude": "attitude_score",
    "understanding": "understanding_score",
    "homework": "homework_score",
    "qna_difficulty": "qna_difficulty_score",
}

def numeric_trend_node(state: Dict[str, Any]) -> Dict[str, Any]:
    raw = state.get("student_data", [])
    if len(raw) < 2:
        raise ValueError("비교를 위해 최소 2회 수업 데이터가 필요합니다.")
    hist = sorted(raw, key=lambda x: x["date"])
    prev, today = hist[-2], hist[-1]
    result = {}
    for k, f in METRICS.items():
        t, p = _i(today.get(f, 3)), _i(prev.get(f, 3))
        d = t - p
        trend = "상승" if d > 0 else ("하락" if d < 0 else "변화 없음")
        past = [_i(r.get(f, 3)) for r in hist[:-1]]
        result[k] = {"today": t, "prev": p, "diff": d, "trend": trend, "past_avg": round(mean(past), 2) if past else t}
    state["numeric_trend"] = result
    return state

def _trend_text_rule(nt: Dict[str, Any]) -> str:
    def say(label, d):
        if d["diff"] > 0:  m = "최근 흐름이 좋아지고 있습니다."
        elif d["diff"] < 0: m = "최근 다소 둔화되는 모습이 보입니다."
        else:               m = "최근 수준을 안정적으로 유지하고 있습니다."
        return f"{label}은 {m}"
    return " ".join([
        say("수업태도", nt["attitude"]),
        say("수업이해도", nt["understanding"]),
        say("과제평가", nt["homework"]),
        say("질문난이도", nt["qna_difficulty"]),
    ])

def trend_explainer_node(state: Dict[str, Any]) -> Dict[str, Any]:
    nt = state.get("numeric_trend")
    if not nt:
        raise ValueError("numeric_trend가 없습니다.")
    if not USE_LLM:
        state["numeric_trend_text"] = _trend_text_rule(nt)
        return state
    system_msg = ("너는 교사용 요약 비서다. 직전 수업 대비 변화를 학부모가 이해하기 쉽게 간결한 한국어로 작성한다. 숫자는 말하지 말고, 항목별 1문장.")
    def line(key, label):
        d = nt[key]
        return f"- {label}: today={d['today']}, prev={d['prev']}, diff={d['diff']}, trend={d['trend']}, past_avg={d['past_avg']}"
    user_msg = "\n".join([
        "[지표 데이터]",
        line("attitude","수업태도"),
        line("understanding","수업이해도"),
        line("homework","과제평가"),
        line("qna_difficulty","질문난이도"),
        "",
        "[작성 규칙]",
        "1) 점수 직접 언급 금지.",
        "2) 오늘 기준 변화(상승/하락/유지)를 자연스럽게.",
        "3) 네 해석 가이드의 뉘앙스로 현재 상태를 한 문장으로.",
        "4) 각 항목 1문장, 총 4문장."
    ])
    text = get_llm().invoke([("system", system_msg), ("user", user_msg)]).content
    state["numeric_trend_text"] = text.strip()
    return state

def build_graph():
    g = StateGraph(dict)
    g.add_node("numeric_trend", numeric_trend_node)
    g.add_node("trend_text", trend_explainer_node)
    g.set_entry_point("numeric_trend")
    g.add_edge("numeric_trend", "trend_text")
    g.add_edge("trend_text", END)
    return g.compile()
