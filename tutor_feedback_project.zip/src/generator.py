from typing import Dict

ATTITUDE_MAP = {
    5: "수업 전반에 활발히 참여하며, 질문과 의견 제시로 분위기를 이끎.",
    4: "대부분 성실하게 임하며, 잠깐 흐트러져도 곧 집중을 회복함.",
    3: "참여 의지는 있으나 발언 빈도가 낮아 추가적인 참여 유도가 필요함.",
    2: "집중 유지가 어렵고 참여가 소극적이어서 지속적인 관심과 지원이 필요함.",
    1: "수업 몰입도와 참여도가 매우 낮아 목표 달성을 위해 강력한 지도·관리가 요구됨.",
}
UNDERSTANDING_MAP = {
    5: "학습 내용을 깊이 있게 파악하고, 변형·응용 과제도 스스로 해결함.",
    4: "핵심 내용을 잘 이해하며, 기본 수준의 응용 문제는 큰 어려움 없이 수행함.",
    3: "기초 개념은 이해하나, 난도가 높은 문제 해결에는 도움을 필요로 함.",
    2: "주요 개념 이해가 미흡해 반복 학습과 추가 자료 지원이 필요함.",
    1: "전반적인 기초부터 재학습이 필요한 수준임.",
}
HOMEWORK_MAP = {
    5: "모든 과제를 정성껏 완수하며, 정확성과 완성도가 높고 제출 기한을 지킴.",
    4: "대부분 수행하였으나 일부 세부 사항에서 실수나 누락이 있음.",
    3: "과제의 절반 이상을 제출했으나 정확성·완성도가 부족함.",
    2: "일부만 제출하거나 기한을 지키지 않는 경우가 잦음.",
    1: "과제를 거의 제출하지 않거나 미제출함.",
}
QNA_MAP = {
    5: "적극적으로 질문하며, 질문의 내용이 심화적임",
    4: "빈번하게 질문하며, 질문의 내용이 기초, 응용 수준임",
    3: "질문하기는 하되, 질문의 내용이 기초적인 수준임",
    2: "질문이 거의 없으며, 질문의 내용이 수업과 무관함",
    1: "질문이 없으며, 교수자의 질문에도 대답을 거의 하지 않음",
}

def _attend_phrase(att: str) -> str:
    return "지각으로 수업을 시작해 초반 일부 내용을 놓쳤습니다." if att == "지각" else "출석하여 수업 전 과정을 참여했습니다."

def _i(v, default=3):
    try: return int(v)
    except: return default

def generate_three_sections(rec: Dict) -> Dict[str, str]:
    att = str(rec.get("attendance", "출석"))
    a = _i(rec.get("attitude_score", 3))
    u = _i(rec.get("understanding_score", 3))
    h = _i(rec.get("homework_score", 3))
    q = _i(rec.get("qna_difficulty_score", 3))
    topics = str(rec.get("topics", "")).rstrip(".")
    memo = str(rec.get("manager_comment", "")).strip()
    name = rec.get("student_name") or rec.get("student_id") or "학생"

    remedial = (f"{topics}를 학습했습니다. {UNDERSTANDING_MAP[u]} {HOMEWORK_MAP[h]} {QNA_MAP[q]}." + (f" {memo}" if memo else "")).strip()
    attitude_txt = f"{ATTITUDE_MAP[a]} {QNA_MAP[q]}. {_attend_phrase(att)}".strip()
    overall = (f"{name} 학생은 {ATTITUDE_MAP[a].rstrip('.')}이며 {UNDERSTANDING_MAP[u].rstrip('.')}입니다. "
               f"{HOMEWORK_MAP[h]} 향후 '{topics}' 영역에서의 성취를 높이기 위해 꾸준한 연습을 이어간다면 더 큰 발전이 기대됩니다.").strip()
    return {"수업보완": remedial, "수업태도": attitude_txt, "전체수업 Comment": overall}
