import pandas as pd
from pathlib import Path

IN_PATH = "data/with_comments_demo.csv"  # 또는 with_comments.csv
OUT_DIR = Path("reports/out")
OUT_DIR.mkdir(parents=True, exist_ok=True)

def main():
    df = pd.read_csv(IN_PATH, parse_dates=["date"])
    df["month"] = df["date"].dt.strftime("%Y-%m")
    agg = df.groupby(["student_id", "month"]).agg(
        attitude_avg=("attitude_score","mean"),
        understanding_avg=("understanding_score","mean"),
        homework_avg=("homework_score","mean"),
        qa_avg=("qna_difficulty_score","mean"),
        tardy_count=("attendance", lambda x: (x=="지각").sum()),
        sessions=("date","count"),
    ).reset_index()

    rep = (df.sort_values(["student_id","date"])
             .groupby(["student_id","month"])
             .agg(rep_overall=("전체수업 Comment","first"))
             .reset_index())

    out = agg.merge(rep, on=["student_id","month"], how="left")
    out_path = OUT_DIR / "monthly_summary.xlsx"
    out.to_excel(out_path, index=False)
    print(f"Saved -> {out_path}")

if __name__ == "__main__":
    main()
