import os, pandas as pd
from tqdm import tqdm
from generator import generate_three_sections
from trend_pipeline import build_graph

IN_PATH = os.environ.get("IN_PATH", "data/input.csv")
OUT_PATH = os.environ.get("OUT_PATH", "data/with_comments.csv")

REQ_COLS = [
    "date","student_id","attendance",
    "attitude_score","understanding_score","homework_score","qna_difficulty_score",
    "topics","manager_comment"
]

def main():
    df = pd.read_csv(IN_PATH)
    missing = [c for c in REQ_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"CSV에 필요한 컬럼이 없습니다: {missing}")

    for i in tqdm(range(len(df)), desc="Generating comments"):
        rec = df.iloc[i].to_dict()
        gen = generate_three_sections(rec)
        for k, v in gen.items():
            df.at[i, k] = v

    df["_trend_summary_"] = ""
    for sid, g in df.groupby("student_id"):
        g = g.sort_values("date")
        if len(g) < 2: 
            continue
        graph = build_graph()
        out = graph.invoke({"student_data": g.to_dict(orient="records")})
        df.loc[g.index, "_trend_summary_"] = out.get("numeric_trend_text","")

    os.makedirs(os.path.dirname(OUT_PATH) or ".", exist_ok=True)
    df.to_csv(OUT_PATH, index=False, encoding="utf-8-sig")
    print(f"Saved -> {OUT_PATH}")

if __name__ == "__main__":
    main()
